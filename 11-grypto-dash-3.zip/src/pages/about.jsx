const AboutPage = () => {
  return (
    <div>
      <h1>About Us</h1>
      <p>Welcome to the Crypto Dashboard!</p>
    </div>
  );
};
export default AboutPage;