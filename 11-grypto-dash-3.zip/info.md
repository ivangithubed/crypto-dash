### react-router-dom
{BrowserRouter, Routes, Route}
HomePage - './pages/home'
AboutPage - './pages/about'

App 

    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/:id" element={<PostPage />} />
      </Routes>
    </BrowserRouter>
